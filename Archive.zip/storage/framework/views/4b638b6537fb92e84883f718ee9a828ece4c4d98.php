<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'المرفقات'); ?>

<body style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">
    
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>"></div>
    </nav>

    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">المرفقات</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <?php if(count($errors) > 0): ?>
                                <div class="alert alert-danger text-right">
                                  <strong>خطأ!</strong> حدث خطأ أثناء الرفع<br><br>
                                  <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </ul>
                                </div>
                            <?php endif; ?>
                            <?php if(session('success')): ?>
                                <div class="alert alert-success text-right">
                                  <?php echo e(session('success')); ?>

                                </div> 
                            <?php endif; ?>
                            <form method="post" class="text-right" action="<?php echo e(url('form')); ?>" enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for=""><strong>رفع المرفقات المطلوبة</strong><br></label></div>
                                        <div class="input-group control-group increment" >
                                              <input type="file" name="filename[]" class="form-control">
                                              <div class="input-group-btn"> 
                                                <button class="btn btn-success" type="button"  style="background-color:#006837; color:white;"><i class="glyphicon glyphicon-plus"></i>إضافة ملف</button>
                                              </div>
                                            </div>
                                            <div class="clone hide">
                                              <div class="control-group input-group" style="margin-top:10px">
                                                <input type="file" name="filename[]" class="form-control">
                                                    <div class="input-group-btn"> 
                                                      <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> حذف</button>
                                                    </div>
                                              </div>
                                            </div>
                                          <div class="mt-5"><label for=""><strong>هل تم رفع الملفات</strong><br></label>
                                            <select name="take_image" class="form-control">
                                              <optgroup>
                                                <option>نعم</option>
                                                <option>لا</option>
                                              </optgroup>
                                            </select>
                                          </div>

                                        <div class="form-group">
                                          <button class="btn btns mt-4" type="submit" style="width: 106px; background-color:#006837; color:white;">رفع الملفات</button>
                                          <a href="<?php echo e(route('openfile')); ?>" class="btn btns mt-4" type="button"  style="background-color:#006837; color:white;">التالي<i class="fa fa-arrow-left"></i></a>
                                        </div>
</form>

<script type="text/javascript">

    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/attachments/create.blade.php ENDPATH**/ ?>