<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'المعلومات الشخصية'); ?>

<body style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">
            <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">البيانات الشخصية</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="alert alert-danger text-right"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                            <form action="<?php echo e(route('personalInfo.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="first_name"><strong>الاسم الأول&nbsp;</strong></label><input class="form-control" type="text" name="first_name"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="second_name"><strong>اسم الاب</strong></label><input class="form-control" type="text" name="second_name"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="third_name"><strong>اسم الجد</strong><br></label><input class="form-control" type="text" name="third_name"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="family_name"><strong>اسم العائلة</strong></label><input class="form-control" type="text" name="family_name"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="sex">
                                            <strong>الجنس</strong>
                                                <br></label>
                                                <select name="gender" class="form-control"><optgroup label="  ">
                                                    <option>انثى</option>
                                                    <option>ذكر</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                    <!-- if user saudi -->
                                <?php if(auth()->user()->user_type == 'saudi'): ?>
                                    <div class="col">
                                        <div class="form-group"><label for="national_id"><strong>رقم الهوية الوطنية</strong></label><input class="form-control" type="intger" name="national_id"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="place_national"><strong>جهة الإصدار</strong><br></label><input class="form-control" type="intger" name="place_national"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="place_birth"><strong>مكان الميلاد</strong></label><input class="form-control" type="intger" name="place_birth"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="date_birth"><strong>تاريخ الميلاد</strong><br></label><input class="form-control" type="date" name="date_birth"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="date_national"><strong>تاريخ إصدار البطاقة</strong></label><input class="form-control" type="date" name="date_national"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="date_ex_national"><strong>تاريخ إنتهاء البطاقة</strong><br></label><input class="form-control" type="date" name="date_ex_national"></div>
                                    </div>
                                    <div class="col"></div>
                                </div>
                                <?php endif; ?>
                                <!-- if user non saudi -->
                                <?php if(auth()->user()->user_type == 'non_saudi'): ?>


                                <div class="col">
                                        <div class="form-group"><label for="passport_number"><strong>رقم جواز السفر</strong></label><input class="form-control" type="text" name="passport_number"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="passport_place"><strong>جهة اصدار جواز السفر</strong><br></label><input class="form-control" type="text" name="passport_place"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="passport_date"><strong>تاريخ اصدار جواز السفر</strong></label><input class="form-control" type="intger" name="passport_date"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="license_number"><strong>رقم رخصة الإقامة</strong><br></label><input class="form-control" type="number" name="license_number"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="license_place"><strong>مكان اصدار رخصةالإقامة</strong></label><input class="form-control" type="date" name="license_place"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="date_ex_license"><strong>تاريخ إنتهاء الإقامة</strong><br></label><input class="form-control" type="date" name="date_ex_license"></div>
                                    </div>
                                    <div class="col"></div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="job"><strong>المهنة المسجلة في رخصة الإقامة</strong><br></label><input class="form-control" type="date" name="job"></div>
                                    </div>
                                    <div class="col"></div>
                                </div>

                                <?php endif; ?>

                                <div class="form-group">
                                    <button class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;">حفظ</button>
                                    <a  href="<?php echo e(route('contactInfo.create')); ?>" class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;">التالي<i class="fa fa-arrow-left"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/personal_information/create.blade.php ENDPATH**/ ?>