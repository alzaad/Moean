<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'تسجيل '); ?>


<br>
<body class="login-dark" style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">
    <div class="login-dark" style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>);">
        <form method="POST" action="<?php echo e(route('register')); ?>"><a class="d-flex justify-content-center" href=""><img class="mx-auto" src="<?php echo e('/img/شعار%20شفاف.png'); ?>" width="100px" height="100px"></a>
            <?php echo csrf_field(); ?>
            <p class="login mt-5">انشاء حساب</p>
            <div class="form-group">
                <input class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="text" placeholder="الاسم" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="email" name="email" placeholder="البريد الالكتروني" required>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="كلمة المرور" required="">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
                <input class="form-control" type="password" name="password" placeholder="تأكيد كلمة المرور" required=""></div>
                <p class="text-dark text-right" style="font-weight: bold;">الجنسية</p>
                    <div class="text-right">
                        <label style="color:black;" class="radio-inline">
                            <input type="radio" name="user_type" value="saudi" checked><?php echo e(__('سعودي')); ?>

                        </label>
                        <label style="color:black;" class="radio-inline">
                            <input type="radio" name="user_type" value="non_saudi"><?php echo e(__('غير سعودي')); ?>

                        </label>
                    </div>
            <div>
                <div class="form-group"><a class="linkform" href="#"><br>بالضفط على "تسجيل" انت توافق على&nbsp;الشروط و الأحكام.<br></a></div>
            </div>
            <div class="form-group"><button class="btn btn-primary btn-block mt-0" type="submit"><?php echo e(__(' تسجيل')); ?></button></div>
        </form>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/auth/register.blade.php ENDPATH**/ ?>