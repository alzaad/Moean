<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'تسجيل دخول عضو اللجنة'); ?>

<body class="login-dark" >
    <div class="login-dark" style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>);">

        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="post" action="<?php echo e(route('committee.check')); ?>">
            <?php echo csrf_field(); ?>
            <a class="d-flex justify-content-center" href=""><img class="mx-auto" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>" width="100px" height="100px"></a>
            <p class="login mt-5">تسجيل دخول عضو اللجنة</p>
            <div class="form-group">
            <input class="form-control" type="integer" name="committees_number" placeholder="رقم عضو اللجنة" required>
                <?php if($alert = Session::get('alert')): ?>
                    <div class="alert alert-danger">
                        <?php echo e($alert); ?>

                    </div>
                <?php endif; ?>
                <div class="invalid-feedback">
                    <p>Paragraph</p>
                </div>
            </div>
            <div class="form-group">
                <div class="invalid-feedback"></div>
            </div>
            <div class="empty"></div>                     

            <div class="form-group">
                <button class="btn btn-primary btn-block mt-5" type="submit"><?php echo e(__('دخول')); ?></button>
            </div>
          
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/committee/login.blade.php ENDPATH**/ ?>