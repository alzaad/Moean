<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'عرض بيانات المستفيد'); ?>

<nav class="navbar navbar-light navbar-expand-md navigation-clean">
            <div class="container"><img class="ml-auto logosize" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>"></div>
        </nav>

<form action="" method="get" class="form">
    <?php echo csrf_field(); ?>
    <body style="background: #e7e2dd; font-family:Cairo;">

        <div class="container-fluid" style="width: 100%;margin-top: 70px;margin-bottom: 60px;">
            <div class="row">
                <div class="col">
                    <div class="card shadow mb-4" style="text-align: right;">
                        <div class="card-header py-3" style="background: rgb(255,255,255);">
                            <h5 class="m-0 font-weight-bold" style="color: #006837;">عرض طلبات المستفيدين</h5>
                        </div>
                        <div class="card-body">
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        
    
            <thead>
                <tr>
                <!-- Personal Information -->
                    <th scope="col">الإسم الأول</th>
                    <th scope="col">الإسم الثاني</th>
                    <th scope="col">الإسم الثالث</th>
                    <th scope="col">إسم العائلة</th>
                    <th scope="col">الجنس</th>
                    <th scope="col">رقم الهوية</th>
                    <th scope="col">مكان إصدار الهوية</th>
                    <th scope="col">تاريخ إصدار الهوية</th>
                    <th scope="col">تاريخ إنتهاء الهوية</th>
                    <th scope="col">مكان الميلاد</th>
                    <th scope="col">تاريخ الميلاد</th>
                    <th scope="col">رقم الجواز</th>
                    <th scope="col">مكان إصدار الجواز</th>
                    <th scope="col">تاريخ إصدار الجواز</th>
                    <th scope="col">رقم الرخصة </th>
                    <th scope="col">مكان الرخصة </th>
                    <th scope="col">تاريخ إنتهاء الرخصة </th>
                    <th scope="col"> الوظيفة(المسجلة في رخصة الإقامة)</th>
                </tr>
            </thead>
            
                <tr>
                    <!-- Personal Information -->
                    <td><?php echo e($personal_infos->first_name); ?></td>
                    <td><?php echo e($personal_infos->second_name); ?></td>
                    <td><?php echo e($personal_infos->third_name); ?></td>
                    <td><?php echo e($personal_infos->family_name); ?></td>
                    <td><?php echo e($personal_infos->gender); ?></td>
                    <td><?php echo e($personal_infos->national_id); ?></td>
                    <td><?php echo e($personal_infos->place_national); ?></td>
                    <td><?php echo e($personal_infos->date_national); ?></td>
                    <td><?php echo e($personal_infos->date_ex_national); ?></td>
                    <td><?php echo e($personal_infos->place_birth); ?></td>
                    <td><?php echo e($personal_infos->date_birth); ?></td>
                    <td><?php echo e($personal_infos->passport_number); ?></td>
                    <td><?php echo e($personal_infos->passport_place); ?></td>
                    <td><?php echo e($personal_infos->passport_date); ?></td>
                    <td><?php echo e($personal_infos->license_number); ?></td>
                    <td><?php echo e($personal_infos->license_place); ?></td>
                    <td><?php echo e($personal_infos->date_ex_license); ?></td>
                    <td><?php echo e($personal_infos->job); ?></td>
                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        
    
            <thead>
                <tr>
                    <!-- Contact Information -->
                    <th scope="col">الإيميل</th>
                    <th scope="col">رقم الهاتف</th>
                    <th scope="col">رقم الجوال</th>
                    <th scope="col">رقم الجوال (واتساب)</th>
                    <th scope="col">رقم هاتف آخر</th>
                    <th scope="col">صلة القرابة مع مقدم الطلب</th>
                </tr>
            </thead>
            
                <tr>
                <!-- Contact Information -->
                <td><?php echo e($contact_infos->email); ?></td>
                    <td><?php echo e($contact_infos->phone_number); ?></td>
                    <td><?php echo e($contact_infos->mobile_number); ?></td>
                    <td><?php echo e($contact_infos->whatsapp_number); ?></td>
                    <td><?php echo e($contact_infos->other_number); ?></td>
                    <td><?php echo e($contact_infos->relative); ?></td>
                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        
    
            <thead>
                <tr>
                    <!-- job Information -->
                    <th scope="col">الوظيفة</th>
                    <th scope="col"> مكان الوظيفة</th>
                    <th scope="col">هاتف العمل</th>
                    <th scope="col">التعليم</th>
                    <th scope="col">نوع الراتب</th>
                    <th scope="col">الراتب</th>
                </tr>
            </thead>
                <tr>
                <!-- job Information -->
                    <td><?php echo e($job_infos->job); ?></td>
                    <td><?php echo e($job_infos->job_place); ?></td>
                    <td><?php echo e($job_infos->phone_number); ?></td>
                    <td><?php echo e($job_infos->education); ?></td>
                    <td><?php echo e($job_infos->salary); ?></td>
                    <td><?php echo e($job_infos->salary_month); ?></td>
                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        
    <thead>
                <tr>
                    <!-- Social Information -->
                    <th scope="col">الحالة الإجتماعية</th>
                    <th scope="col"> عدد الزوجات </th>
                    <th scope="col"> عدد أفراد الأسرة المعالين </th>
                    <th scope="col">عدد الذكور</th>
                    <th scope="col">عدد الإناث</th>
                    <th scope="col">الذي يتولى الإنفاق على الأسرة</th>
                    <th scope="col">هل يتولى العائل أفراد آخرين</th>
                    <th scope="col">عدد الأفراد الذين يتولى العائل أمرهم</th>
                    <th scope="col">لماذا يتولى أمرهم</th>
                    <th scope="col">عدد الدارسين بالمرحلة الإبتدائية</th>
                    <th scope="col">عدد الدارسين بالمرحلة المتوسطة</th>
                    <th scope="col">عدد الدارسين بالمرحلة الثانوية</th>
                    <th scope="col">عدد الدارسين بالمرحلة الجامعية</th>
                    <th scope="col">الخريجين</th>
                    <th scope="col">الحالة الصحية للعائل</th>
                    <th scope="col">معلومات التابعين</th>
                    <th scope="col">الحالة الصحية للتابعين</th>
                </tr>
            </thead>
                <tr>
                    <!-- Social Information -->
                    <td><?php echo e($information->social_status); ?></td>
                    <td><?php echo e($information->wife_number); ?></td>
                    <td><?php echo e($information->family_number); ?></td>
                    <td><?php echo e($information->male_number); ?></td>
                    <td><?php echo e($information->female_number); ?></td>
                    <td><?php echo e($information->who_spend); ?></td>
                    <td><?php echo e($information->other_person); ?></td>
                    <td><?php echo e($information->other_person_num); ?></td>
                    <td><?php echo e($information->other_person_reason); ?></td>
                    <td><?php echo e($information->primary_school); ?></td>
                    <td><?php echo e($information->middle_school); ?></td>
                    <td><?php echo e($information->high_school); ?></td>
                    <td><?php echo e($information->university); ?></td>
                    <td><?php echo e($information->graduated); ?></td>
                    <td><?php echo e($information->disease); ?></td>
                    <td><?php echo e($information->children_informations); ?></td>
                    <td><?php echo e($information->disease_informations); ?></td> 

                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        <thead>
                <tr>
                    <!-- commitments Information -->
                    <th scope="col">الإيجار الشهري</th>
                    <th scope="col">فاتورة كهرباء</th>
                    <th scope="col">فاتورة ماء</th>
                    <th scope="col">أقساط شهرية</th>
                    <th scope="col">قسط بنك التنمية الإجتماعية</th>
                    <th scope="col">قسط البنك التجاري</th>
                    <th scope="col">ديون شخصية</th>
                    <th scope="col">مستلزمات المواليد والأطفال</th>
                    <th scope="col">عيادات ومستوصفات أهلية</th>
                    <th scope="col">تعبئة البنزين أو الديزل وتغيير</th>
                    <th scope="col">صيانة أعطال السيارة </th>
                    <th scope="col">مصروفات النقل </th>
                    <th scope="col"> هل لديك أي أعباء مالية أو ديون أخرى</th>
                    <th scope="col"> ماهي الديون الأخرى</th>
                </tr>
            </thead>
                <tr>
                <!-- commitments Information -->
                <td><?php echo e($commitments->rent_home); ?></td>
                <td><?php echo e($commitments->electricity_bill); ?></td>
                <td><?php echo e($commitments->water_bill); ?></td>
                <td><?php echo e($commitments->monthly_fees); ?></td>
                <td><?php echo e($commitments->monthly_fees_bank); ?></td>
                <td><?php echo e($commitments->monthly_fees_eco_bank); ?></td>
                <td><?php echo e($commitments->debts_info); ?></td>
                <td><?php echo e($commitments->supplies); ?></td>
                <td><?php echo e($commitments->hospital); ?></td>
                <td><?php echo e($commitments->gas); ?></td>
                <td><?php echo e($commitments->maintenance); ?></td>
                <td><?php echo e($commitments->transfer); ?></td>
                <td><?php echo e($commitments->debts); ?></td>
                <td><?php echo e($commitments->personal_debts); ?></td>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        <thead>
                <tr>
                    <!-- home Information -->
                    <th scope="col">موقع السكن</th>
                    <th scope="col">وصف السكن</th>
                    <th scope="col">رقم المبنى</th>
                    <th scope="col">نوع السكن</th>
                    <th scope="col"> N احداثيات السكن</th>
                    <th scope="col"> E احداثيات السكن</th>
                    <th scope="col">ملكية السكن</th>
                    <th scope="col">قيمة الإيجار</th>
                    <th scope="col">هل قيمة الإيجار مناسبة للسكن </th>
                    <th scope="col">عدد جميع الغرف</th>
                    <th scope="col"> هل عدد الغرف كافية</th>
                    <th scope="col">هل المنزل مناسب للسكن </th>
                    <th scope="col">السبب اذا كان المنزل غير مناسب </th>
                    <th scope="col"> جودة السكن</th>
                    <th scope="col">تقييم حالة غرف النوم</th>
                    <th scope="col"> تقييم حالة المطبخ</th>
                    <th scope="col">تقييم حالة دورات المياة </th>
                    <th scope="col">تقييم حالة المستودع </th>
                    <th scope="col">تقييم غرفة السائق</th>
                    <th scope="col">تقييم حالة الصالة</th>
                    <th scope="col"> تقييم غرفة الطعام</th>
                    <th scope="col">تقييم المجلس </th>
                    <th scope="col">تقييم السطح </th>
                    <th scope="col">تقييم الملحق الخارجي</th>
                    <th scope="col">تقييم حالة الحوش</th>
                    <th scope="col">تقييم حالة الأثاث</th>
                    <th scope="col">هل الغرف مؤثثة</th>
                    <th scope="col"> عدد الغسالات</th>
                    <th scope="col">عدد مكيفات الشبك </th>
                    <th scope="col"> عدد مكيفات السبيليت</th>
                    <th scope="col">عدد مكيفات الصحراوي </th>
                    <th scope="col">عدد الثلاجات </th>
                    <th scope="col">عدد الفريزر</th>
                    <th scope="col">عدد مكنسة الكهرب</th>
                    <th scope="col">عدد السخانات</th>
                    <th scope="col">عدد المراوح</th>
                    <th scope="col">عدد الدفايات</th>
                    <th scope="col">عدد براد الماء</th>
                    <th scope="col"> تقييم حالة الغسالة</th>
                    <th scope="col"> تقييم حالة مكيفات الشبك</th>
                    <th scope="col"> تقييم حالة مكيفات السبيليت</th>
                    <th scope="col"> تقييم حالة مكيفات الصحراوي</th>
                    <th scope="col"> تقييم حالة الثلاجات</th>
                    <th scope="col"> تقييم حالة الفريزر</th>
                    <th scope="col"> تقييم حالة مكنسةالكهرب</th>
                    <th scope="col"> تقييم حالة السخانات</th>
                    <th scope="col"> تقييم حالة الراوح</th>
                    <th scope="col"> تقييم حالة الدفايات</th>
                    <th scope="col"> تقييم حالة براد الماء</th>
                    <th scope="col"> إلى ماذا يحتاج السكن</th>
                    <th scope="col"> مما يتكون السكن</th>
                </tr>
            </thead>
                <tr>
                <!-- home Information -->
                <td><?php echo e($location_infos->place); ?></td>
                <td><?php echo e($location_infos->description); ?></td>
                <td><?php echo e($location_infos->building_num); ?></td>
                <td><?php echo e($location_infos->building_type); ?></td>
                <td><?php echo e($location_infos->location_N); ?></td>
                <td><?php echo e($location_infos->location_E); ?></td>
                <td><?php echo e($location_infos->building_ownership); ?></td>
                <td><?php echo e($location_infos->building_rent); ?></td>
                <td><?php echo e($location_infos->rent_evaluate); ?></td>
                <td><?php echo e($location_infos->room_number_all); ?></td>
                <td><?php echo e($location_infos->room_number); ?></td>
                <td><?php echo e($location_infos->home_status); ?></td>
                <td><?php echo e($location_infos->status_reason); ?></td>
                <td><?php echo e($location_infos->home_quality); ?></td>
                <td><?php echo e($location_infos->bedroom_evaluate); ?></td>
                <td><?php echo e($location_infos->kitchen_evaluate); ?></td>
                <td><?php echo e($location_infos->bathroom_evaluate); ?></td>
                <td><?php echo e($location_infos->store_evaluate); ?></td>
                <td><?php echo e($location_infos->driverroom_evaluate); ?></td>
                <td><?php echo e($location_infos->hall_evaluate); ?></td>
                <td><?php echo e($location_infos->dining_room_evaluate); ?></td>
                <td><?php echo e($location_infos->living_room_evaluate); ?></td>
                <td><?php echo e($location_infos->roof_evaluate); ?></td>
                <td><?php echo e($location_infos->annex_evaluate); ?></td>
                <td><?php echo e($location_infos->outdoor_evaluate); ?></td>
                <td><?php echo e($location_infos->evaluate_furniture); ?></td>
                <td><?php echo e($location_infos->furnished); ?></td>
                <td><?php echo e($location_infos->washing_machine); ?></td>
                <td><?php echo e($location_infos->conditioner_1); ?></td>
                <td><?php echo e($location_infos->conditioner_2); ?></td>
                <td><?php echo e($location_infos->conditioner_3); ?></td>
                <td><?php echo e($location_infos->refrigerator); ?></td>
                <td><?php echo e($location_infos->fraser); ?></td>
                <td><?php echo e($location_infos->cleaner); ?></td>
                <td><?php echo e($location_infos->heater); ?></td>
                <td><?php echo e($location_infos->fan); ?></td>
                <td><?php echo e($location_infos->fireplace); ?></td>
                <td><?php echo e($location_infos->water_cooler); ?></td>
                <td><?php echo e($location_infos->washing_machineـevaluate); ?></td>
                <td><?php echo e($location_infos->conditioner_1_evaluate); ?></td>
                <td><?php echo e($location_infos->conditioner_2_evaluate); ?></td>
                <td><?php echo e($location_infos->conditioner_3_evaluate); ?></td>
                <td><?php echo e($location_infos->refrigerator_evaluate); ?></td>
                <td><?php echo e($location_infos->fraser_evaluate); ?></td>
                <td><?php echo e($location_infos->cleaner_evaluate); ?></td>
                <td><?php echo e($location_infos->heater_evaluate); ?></td>
                <td><?php echo e($location_infos->fan_evaluate); ?></td>
                <td><?php echo e($location_infos->fireplace_evaluate); ?></td>
                <td><?php echo e($location_infos->water_cooler_evaluate); ?></td>
                <td><?php echo e($location_infos->category); ?></td>
                <td><?php echo e($location_infos->home_category); ?></td>
                </tr> 
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        <thead>
                <tr>
                    <!-- Bank Information -->
                    <th scope="col">اسم البنك</th>
                    <th scope="col">رقم الحساب</th>
                    <th scope="col">رقم الأيبان</th>
                </tr>
            </thead>
                <tr>
                <!-- Bank Information -->
                <td><?php echo e($bank_information->bank_name); ?></td>
                    <td><?php echo e($bank_information->bank_account); ?></td>
                    <td><?php echo e($bank_information->iban); ?></td>
                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
        <thead>
                <tr>
                    <!-- Open file  -->
                    <th scope="col">الملفات المطلوبة</th>
                    <th scope="col">هل تم رفع الملفات</th>
                    <th scope="col">التأكيد على رفع الملفات</th>
                </tr>
            </thead>
                <tr>
                <!--  Open file  -->
                <th>
                        <?php $__currentLoopData = json_decode($openfiles_infos->filename); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="_blank" href="<?php echo e(asset('/attach/images/'.$image)); ?>"> <img src="<?php echo e(asset('/attach/images/'.$image)); ?>" style="width:50px;height:50px;"></a><br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>
                <td><?php echo e($openfiles_infos->take_image); ?></td>
                <td><?php echo e($openfiles_infos->checkvalue); ?></td>
                </tr>
        </table>
    </div>
                            </div>
                            <div class="form-group f-g">
                                <form><div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <!--  Attachments  -->
                    <th scope="col">الملفات المطلوبة</th>
                    <th scope="col">هل تم التقاط الصور</th>
                    
                </tr>
            </thead>
                <tr>
                <!-- Attachments  -->
                <th>
                        <?php $__currentLoopData = json_decode($attachments_infos->filename); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a target="_blank" href="<?php echo e(asset('/attach/images/'.$image)); ?>"> <img src="<?php echo e(asset('/attach/images/'.$image)); ?>" style="width:50px;height:50px;"></a><br/>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </th>
                <td><?php echo e($openfiles_infos->take_image); ?></td>
                <td><?php echo e($openfiles_infos->checkvalue); ?></td>
                </tr>
        </table>
    </div>
</form>                        </div>
                            <div class="form-group f-g">
                                <!-- اللجنة -->
<!-- اللجنة -->
<form action=" <?php echo e(route('opinion')); ?>" class="text-right" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label><strong>حالة المستفيد</strong><br></label><select name="committees_opinion" class="form-control"><option></option><option> مؤهل</option><option>غير مؤهل</option></select></div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label><strong>السبب</strong><br></label><select name="committees_reason" class="form-control"><option></option><option>تجاوز الحد المسموح في صافي الدخل الشهري لرب الأسرة</option><option>لا يحمل الهوية الوطنية</option><option> لا يوجد لدية أسرة</option></select></div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label><strong>ملاحظات اخرى</strong><br></label><textarea  name="committees_note" class="form-control form-control-lg" rows="3"></textarea></div>
                                        </div>
                                    </div>
                                    <div class="form-group"><button class="btn btns mt-4" type="submit" style="width: 103px;">ارسال القرار</button></div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright py-3 text-center text-white" style="background: #2d241b;">
            <div class="container"><small>Copyright ©&nbsp;Brand 2020</small></div>
        </div>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    </body>

</html>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('benefits.committee.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/committee/show.blade.php ENDPATH**/ ?>