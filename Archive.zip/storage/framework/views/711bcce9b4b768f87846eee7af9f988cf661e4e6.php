<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'معلومات السكن'); ?>


<body style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">
    
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">معلومات السكن</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <form action="<?php echo e(route('location.store')); ?>" class="text-right" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for=""><strong>موقع السكن</strong><br></label><input name="place" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>وصف السكن</strong><br></label><input  name="description" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>رقم المبنى</strong><br></label><input name="building_num" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>احداثيات السكن(E)</strong><br></label><input name="location_E"  class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>احداثيات السكن(N)</strong><br></label><input name="location_N" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>نوع السكن</strong><br></label>
                                            <select name="building_type" class="form-control"><optgroup>
                                                <option></option>
                                                <option>فيلا</option>
                                                <option>دور</option>
                                                <option>بيت شعبي</option>
                                                <option>شقة</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong>ملكية السكن</strong><br></label>
                                            <select name="building_type" class="form-control"><optgroup>
                                                <option></option>
                                                <option>ملك</option>
                                                <option>مستأجر</option>
                                                <option>وقف</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="form-group"><label for=""><strong>قيمة الإيجار(في حال كان مستأجر)</strong><br></label><input class="form-control" type="integer" name="building_rent"></div>

                                        <div class="form-group"><label for=""><strong>هل قيمة الإيجار مناسبة للسكن؟</strong><br></label>
                                            <select name="rent_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>نعم</option>
                                                <option>لا</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label for=""><strong>مكونات السكن</strong><br></label>
                                            <br>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="غرفة نوم">
                                                غرفة نوم
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="صالة">
                                                صالة
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="حوش">
                                                حوش
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="مجلس">
                                                مجلس
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="مطبخ">
                                                مطبخ
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="غرفة سائق">
                                                غرفة سائق
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="ملحق خارجي">
                                                ملحق خارجي
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="صالة طعام">
                                                صالة طعام
                                            </label>
                                            <label class="checkbox-inline">
                                                <input name="home_category[]" type="checkbox" value="مستودع">
                                                مستودع
                                            </label>
                                        </div>
                                        <div class="form-group"><label for=""><strong>عدد جميع الغرف بالمنزل </strong><br></label>
                                            <select name="room_number_all" class="form-control"><optgroup>
                                                <option></option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                <option>6</option>
                                                <option>أكثر</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="form-group"><label for=""><strong>هل عدد الغرف كافية </strong><br></label>
                                            <select name="room_number" class="form-control"><optgroup>
                                                <option></option>
                                                <option>نعم</option>
                                                <option>لا</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="form-group"><label for=""><strong>هل وضع المنزل مناسب للسكن </strong><br></label>
                                            <select name="home_status" class="form-control"><optgroup>
                                                <option></option>
                                                <option>نعم</option>
                                                <option>لا</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong>إذا كان غير مناسب اذكر السبب</strong><br></label><input name="status_reason" class="form-control" type="text"></div>

                                        <div class="form-group"><label for=""><strong>ماهو تقييمك لجودة السكن </strong><br></label>
                                            <select name="home_quality" class="form-control"><optgroup>
                                                <option></option>
                                                <option>1</option>
                                                <option>2</option>
                                                <option>3</option>
                                                <option>4</option>
                                                <option>5</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <label for=""><strong>تقييم حالة الغرف</strong><br></label>
                                        <br>
                                        <div class="form-group"><label for=""><strong>غرفة النوم </strong><br></label>
                                            <select name="bedroom_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong>مطبخ </strong><br></label>
                                            <select name="kitchen_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong>دورات المياة </strong><br></label>
                                            <select name="bathroom_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong> مستودع </strong><br></label>
                                            <select name="store_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong> غرفة سائق </strong><br></label>
                                            <select name="driverroom_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong> حوش </strong><br></label>
                                            <select name="outdoor_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        
                                        <div class="form-group"><label for=""><strong> سطح </strong><br></label>
                                            <select name="roof_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong> ملحق خارجي </strong><br></label>
                                            <select name="annex_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong> صالة </strong><br></label>
                                            <select name="hall_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        

                                        <div class="form-group"><label for=""><strong> مجلس </strong><br></label>
                                            <select name="living_room_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>


                                        <div class="form-group"><label for=""><strong> صالة طعام </strong><br></label>
                                            <select name="dining_room_evaluate" class="form-control"><optgroup>
                                                <option></option>
                                                <option>تصدعات</option>
                                                <option>هبوط</option>
                                                <option>خطر</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group">
                                            <label for=""><strong>إلى ماذا يحتاج السكن</strong><br></label>
                                        <br>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value=" أعمال كهربائية">
                                            أعمال كهربائية
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="أعمال سباكة">
                                            أعمال سباكة
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="مطبخ">
                                            مطبخ
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="أبواب">
                                            أبواب
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="حنفيات">
                                            حنفيات
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="شبابيك">
                                            شبابيك
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="صرف صحي">
                                            صرف صحي
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="دهانات">
                                            دهانات
                                        </label>
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="تلبيس">
                                            تلبيس
                                        </label>
                            
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="لمبات">
                                            لمبات
                                        </label>
                            
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="سخانات">
                                            سخانات
                                        </label>
                            
                                        <label class="checkbox-inline">
                                            <input name="category[]" type="checkbox" value="شفاطات هواء">
                                            شفاطات هواء
                                        </label>
                                        <br>
                                        <label for=""><strong>ماهو تقييمك لحالة الأجهزه الكهربائية</strong><br></label>

<div class="form-group"><label for=""><strong> مكيف سبيليت </strong><br></label>
    <select name="conditioner_1_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong> مكيف شبك </strong><br></label>
    <select name="conditioner_2_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong> مكيف صحراوي </strong><br></label>
    <select name="conditioner_3_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>


<div class="form-group"><label for=""><strong> ثلاجة </strong><br></label>
    <select name="refrigerator_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong> فريزر </strong><br></label>
    <select name="fraser_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong> برادة ماء </strong><br></label>
    <select name="water_cooler_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong>غسالة </strong><br></label>
    <select name="washing_machineـevaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong>سخانة </strong><br></label>
    <select name="heater_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong>دفاية  </strong><br></label>
    <select name="fireplace_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong>مكنسة كهرب </strong><br></label>
    <select name="cleaner_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>

<div class="form-group"><label for=""><strong>مروحة شفط</strong><br></label>
    <select name="fan_evaluate" class="form-control"><optgroup>
        <option></option>
        <option>غير متوفر</option>
        <option>بحاجة إلى تغيير</option>
        <option>بحاجة إلى صيانة</option>
        <option>مقبول</option>
        <option>ممتاز</option>
        </optgroup>
    </select>
</div>


<div class="form-group"><label for=""><strong> ماهو تقييمك لحالة الأثاث</strong><br></label>
                                            <select name="evaluate_furniture" class="form-control"><optgroup>
                                                <option></option>
                                                <option>غير متوفر</option>
                                                <option>بحاجة إلى تغيير</option>
                                                <option>بحاجة إلى صيانة</option>
                                                <option>مقبول</option>
                                                <option>ممتاز</option>
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="form-group"><label for=""><strong>هل المجالس مؤثثة</strong><br></label>
                                            <select name="furnished" class="form-control"><optgroup>
                                                <option></option>
                                                <option>نعم</option>
                                                <option>لا</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <button class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;"><?php echo e(__('حفظ')); ?></button>
                                            <a href="<?php echo e(route('form')); ?>" type="button" class="btn btns mt-4"  style="background-color:#006837; color:white;"><?php echo e(__('التالي')); ?><i class="fa fa-arrow-left"></i></a>
                                        </div>
                                        </form>





<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/home/create.blade.php ENDPATH**/ ?>