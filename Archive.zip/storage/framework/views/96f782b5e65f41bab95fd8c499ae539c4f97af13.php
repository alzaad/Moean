<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'تعديل البيانات'); ?>

<body style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">

    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="/img/شعار%20شفاف.png"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">البيانات الشخصية</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <?php if(count($errors) > 0): ?>
                                <div class = "alert alert-danger text-right">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                </div>
                            <?php endif; ?>
                            <form action="<?php echo e(route('profile.update', $id)); ?>" method="post" class="form">
                                <?php echo method_field('PATCH'); ?>
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="first_name"><strong>الاسم الأول</strong></label><input class="form-control" type="text" name="first_name" value="<?php echo e($personal_info['first_name']); ?>"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="second_name"><strong>اسم الاب</strong></label><input class="form-control" type="text" name="second_name" value="<?php echo e($personal_info['second_name']); ?>"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="third_name"><strong>اسم الجد</strong><br></label><input class="form-control" type="text" name="third_name" value="<?php echo e($personal_info['third_name']); ?>"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="family_name"><strong>اسم العائلة</strong></label><input class="form-control" type="text" name="family_name" value="<?php echo e($personal_info['family_name']); ?>"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="sex"><strong>الجنس</strong><br></label><select name="gender" class="form-control"><optgroup><option><?php echo e($personal_info['gender']); ?></option><option>انثى</option><option>ذكر</option></optgroup></select></div>
                                    </div>
                                    <!-- if user saudi -->
                                    <?php if(auth()->user()->user_type == 'saudi'): ?>
                                    <div class="col">
                                        <div class="form-group"><label for="national_id"><strong>رقم الهوية الوطنية</strong></label><input class="form-control" type="text" name="national_id"  value="<?php echo e($personal_info['national_id']); ?>"></div>
                                    </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label for="place_national"><strong>جهة الإصدار</strong><br></label><input class="form-control" type="text" name="place_national" value="<?php echo e($personal_info['place_national']); ?>"></div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group"><label for="place_birth"><strong>مكان الميلاد</strong></label><input class="form-control" type="text" name="place_birth" value="<?php echo e($personal_info['place_birth']); ?>"></div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label for="date_birth"><strong>تاريخ الميلاد</strong><br></label><input class="form-control" type="date" name="date_birth" value="<?php echo e($personal_info['date_birth']); ?>"></div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group"><label for="date_national"><strong>تاريخ إصدار البطاقة</strong></label><input class="form-control" type="date" name="date_national" value="<?php echo e($personal_info['date_national']); ?>"></div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="col">
                                            <div class="form-group"><label for="date_ex_national"><strong>تاريخ إنتهاء البطاقة</strong><br></label><input class="form-control" type="date" name="date_ex_national" value="<?php echo e($personal_info['date_ex_national']); ?>"></div>
                                        </div>
                                        <div class="col"></div>
                                    </div>
                                    <?php endif; ?>
                                    <!-- if user non saudi -->
                                    <?php if(auth()->user()->user_type == 'non_saudi'): ?>
                                        <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label><strong> رقم جواز السفر</strong><br></label><input class="form-control" type="text" name="passport_number"  value="<?php echo e($personal_info['passport_number']); ?>"></div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-group"><label><strong>جهة إصدار جواز السفر</strong></label><input class="form-control" type="text" name="passport_place" value="<?php echo e($personal_info['passport_place']); ?>"></div>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label><strong>تاريخ إصدار جواز السفر</strong><br></label><input class="form-control" type="date" name="passport_date"  value="<?php echo e($personal_info['passport_date']); ?>"></div>
                                                </div>
                                                <div class="col">
                                                    <div class="form-group"><label><strong>رقم رخصة الإقامة</strong></label><input class="form-control" type="integer" name="license_number" value="<?php echo e($personal_info['license_number']); ?>"></div>
                                                </div>
                                            </div>
                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label><strong>مكان إصدار رخصة الإقامة</strong><br></label><input class="form-control" type="text"  name="license_place" value="<?php echo e($personal_info['license_place']); ?>"></div>
                                                </div>
                                                <div class="col"></div>
                                            </div>

                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label><strong>تاريخ إنتهاء الإقامة</strong><br></label><input class="form-control" type="date" name="date_ex_license" value="<?php echo e($personal_info['date_ex_license']); ?>"></div>
                                                </div>
                                                <div class="col"></div>
                                            </div>

                                            <div class="form-row">
                                                <div class="col">
                                                    <div class="form-group"><label><strong>المهنة المسجلة في رخصة الإقامة</strong><br></label><input class="form-control" type="text" name="job" value="<?php echo e($personal_info['job']); ?>"></div>
                                                </div>
                                                <div class="col"></div>
                                            </div>
                                    <?php endif; ?>
                                                <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                    <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">معلومات التواصل</h5>
                                                </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>البريد الألكتروني</strong><br></label><input class="form-control" type="email" name="email" value="<?php echo e($contact_infos->email); ?>"></div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>رقم الجوال</strong></label><input class="form-control" type="text" name="phone_number" value="<?php echo e($contact_infos->phone_number); ?>"></div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>رقم الهاتف</strong><br></label><input class="form-control" type="text" name="mobile_number" value="<?php echo e($contact_infos->mobile_number); ?>"></div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>رقم الجوال (واتساب)</strong></label><input class="form-control" type="text" name="whatsapp_number" value="<?php echo e($contact_infos->whatsapp_number); ?>"></div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>رقم جوال قريب</strong><br></label><input class="form-control" type="text" name="other_number" value="<?php echo e($contact_infos->other_number); ?>" ></div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>صلة القرابة</strong></label>
                                                                <select class="form-control" name="relative">
                                                                    <option><?php echo e($contact_infos->relative); ?></option>
                                                                    <option>والد</option>
                                                                    <option>والدة</option>
                                                                    <option>زوج</option>
                                                                    <option>زوجة</option>
                                                                    <option>ابن</option>
                                                                    <option>جد</option>
                                                                    <option>جدة</option>
                                                                    <option>أخ</option>
                                                                    <option>أخت</option>
                                                                    <option>ابن الإبن</option>
                                                                    <option>عم</option>
                                                                    <option>عمة</option>
                                                                    <option>خال</option>
                                                                    <option>خالة</option>
                                                                    <option>ابن الأخ</option>
                                                                    <option>ابن الأخت</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">معلومات المهنة </h5>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>المهنة</strong></label>
                                                                <select class="form-control"  name="job">
                                                                    <option><?php echo e($job_info['job']); ?></option>
                                                                    <option>موظف/ة حكومي/ة</option>
                                                                    <option>موظف/ة أهلي/ة</option>
                                                                    <option>متقاعد/ة</option>
                                                                    <option>متسبب/ة</option>
                                                                    <option>طالب/ة</option>
                                                                    <option>ربة منزل</option>
                                                                    <option>لايوجد</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>مكان العمل</strong></label>
                                                                <input class="form-control" type="text" name="job_place" value="<?php echo e($job_info['job_place']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>مصدر الدخل</strong></label>
                                                                <select class="form-control" name="salary">
                                                                    <option><?php echo e($job_info['salary']); ?></option>
                                                                    <option>راتب شهري(قطاع عسكري/حكومي)</option>
                                                                    <option>راتب شهري(قطاع خاص)</option>
                                                                    <option>راتب تقاعد(قطاع خاص) </option>
                                                                    <option>الضمان الإجتماعي</option>
                                                                    <option>إعانة سنوية</option>
                                                                    <option>نشاط تجاري</option>
                                                                    <option>غير ذلك</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>الراتب الشهري</strong></label>
                                                                <input class="form-control" type="text" name="salary_month" value="<?php echo e($job_info['salary_month']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>هاتف العمل</strong></label>
                                                                <input class="form-control" type="text" name="phone_number" value="<?php echo e($job_info['phone_number']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group"><label><strong>المؤهل الجامعي</strong></label>
                                                                <select class="form-control" name="education">
                                                                    <option><?php echo e($job_info['education']); ?></option>
                                                                    <option>جامعي</option>
                                                                    <option>ثانوي</option>
                                                                    <option>متوسط</option>
                                                                    <option>ابتدائي</option>
                                                                    <option>يقرأ ويكتب</option>
                                                                    <option>أمي</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">الإفصاح عن الدخل </h5>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>إيجار سنوي</strong></label>
                                                                <input type="integer" name="rent_home" class="form-control"  value="<?php echo e($commitment['rent_home']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>متوسط فاتورة الكهرباء(شهريا)</strong></label>
                                                                <input type="integer" name="electricity_bill" class="form-control" value="<?php echo e($commitment['electricity_bill']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>متوسط فاتورة الماء(شهريا)</strong></label>
                                                                <input type="integer" name="water_bill" class="form-control" value="<?php echo e($commitment['water_bill']); ?>">
                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>أقساط شهرية(الصندوق العقاري)</strong></label>
                                                                <input type="integer" name="monthly_fees" class="form-control" value="<?php echo e($commitment['monthly_fees']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>أقساط شهرية(بنك التنمية الإجتماعية)</strong></label>
                                                                <input type="integer" name="monthly_fees_eco_bank" class="form-control" value="<?php echo e($commitment['monthly_fees_eco_bank']); ?>">                                                            </div>
                                                        </div>
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>أقساط شهرية(بنك تجاري)</strong></label>
                                                                <input type="integer" name="monthly_fees_bank" class="form-control" value="<?php echo e($commitment['monthly_fees_bank']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>ديون شخصية</strong></label>
                                                                <input type="integer" name="personal_debts" class="form-control" value="<?php echo e($commitment['personal_debts']); ?>">
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>مستلزمات المواليد والأطفال (المصروفات الشهرية)</strong></label>
                                                                <input type="integer" name="supplies" class="form-control" value="<?php echo e($commitment['supplies']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>عيادات ومستوصفات أهلية(إجمالي المصروفات الشهرية)</strong></label>
                                                                <input type="integer" name="hospital" class="form-control" value="<?php echo e($commitment['hospital']); ?>">
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>إجمالي مصروفات التنقل(شهريا)</strong></label>
                                                                <input type="integer" name="transfer" class="form-control" value="<?php echo e($commitment['transfer']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>تعبئة البنزين أو الديزل وتغيير الزيت(اجمالي المصروفات شهريا)</strong></label>
                                                                <input type="integer" name="gas" class="form-control" value="<?php echo e($commitment['gas']); ?>">
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>صيانة أعطال السيارة(إجمالي المصروفات شهريا)</strong></label>
                                                                <input type="integer" name="maintenance" class="form-control" value="<?php echo e($commitment['maintenance']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>هل لديك أي أعباء مالية أو ديون أخرى</strong></label>
                                                                <select class="form-control" name="debts">
                                                                    <option><?php echo e($commitment['debts']); ?></option>
                                                                    <option>نعم</option>
                                                                    <option>لا</option>    
                                                                </select>                                                            
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>الديون الأخرى</strong></label>
                                                                <input type="integer" name="debts_info" class="form-control" value="<?php echo e($commitment['debts_info']); ?>">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">معلومات الشخصية </h5>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>الحالة الإجتماعية</strong></label>
                                                                <select class="form-control" name="social_status">
                                                                    <option><?php echo e($information['social_status']); ?></option>
                                                                    <option>رب أسرة</option>
                                                                    <option>مطلقة</option>
                                                                    <option>أرملة</option>
                                                                    <option>مهجورة</option>
                                                                    <option>آخرى</option>
                                                                </select>                                                           
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>إجمالي عدد أفراد الأسرة المعالين</strong></label>
                                                                    <select class="form-control" name="family_number">
                                                                        <option><?php echo e($information['family_number']); ?></option>
                                                                        <option>0</option>
                                                                        <option>1</option>
                                                                        <option>2</option>
                                                                        <option>3</option>
                                                                        <option>4</option>
                                                                        <option>5</option>
                                                                        <option>6</option>
                                                                        <option>7</option>
                                                                        <option>8</option>
                                                                        <option>9</option>
                                                                        <option>10</option>
                                                                        <option>11</option>
                                                                        <option>12</option>
                                                                        <option>13</option>
                                                                    </select>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>عدد الزوجات</strong></label>
                                                                <select class="form-control" name="wife_number">
                                                                    <option><?php echo e($information['wife_number']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                </select>                                                            
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>عدد الذكور</strong></label>
                                                                <select class="form-control" name="male_number">
                                                                    <option><?php echo e($information['male_number']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                    <option>7</option>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>عدد الإناث</strong></label>
                                                                <select class="form-control" name="female_number">
                                                                    <option><?php echo e($information['female_number']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                    <option>7</option>
                                                                </select>                                                          
                                                            </div>
                                                        </div> 
                                                    </div>
                                                    

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>معلومات الذكور والإناث</strong></label>
                                                
                                                                <div class="input-group control-group increment">
                                                    <label> الإسم </label>
                                                        <input name="children_informations[]" type="text" class="form-control">
                                                    <label> تاريخ الميلاد </label>
                                                        <input name="children_informations[]" type="date" class="form-control">
                                                    <label> رقم الهوية الوطنية </label>
                                                        <input  name="children_informations[]" type="integer" class="form-control">
                                                    <div class="input-group-btn"> 
                                                        <button class="btn btn-success" style="background-color:#006837; color:white;" type="button"><i class="glyphicon glyphicon-plus"></i>إضافة تابع</button>
                                                    </div>
                                                </div>
                                                
                                                <div class="clone hide">
                                                    <div class="control-group input-group" style="margin-top:10px">
                                                        <label> الإسم </label>
                                                            <input name="children_informations[]" type="text" class="form-control">
                                                        <label> تاريخ الميلاد </label>
                                                            <input name="children_informations[]" type="date" class="form-control">
                                                        <label> رقم الهوية الوطنية </label>
                                                            <input name="children_informations[]" type="integer" class="form-control">
                                                        <div class="input-group-btn"> 
                                                            <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> حذف</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>من يتولى الإنفاق على الأسرة</strong></label>
                                                                <select class="form-control"  name="who_spend">
                                                                    <option><?php echo e($information['who_spend']); ?></option>
                                                                    <option>والد</option>
                                                                    <option>والدة</option>
                                                                    <option>زوج</option>
                                                                    <option>زوجة</option>
                                                                    <option>ابن</option>
                                                                    <option>جد</option>
                                                                    <option>جدة</option>
                                                                    <option>أخ</option>
                                                                    <option>أخت</option>
                                                                    <option>ابن الإبن</option>
                                                                    <option>عم</option>
                                                                    <option>عمة</option>
                                                                    <option>خال</option>
                                                                    <option>خالة</option>
                                                                    <option>ابن الأخ</option>
                                                                    <option>ابن الأخت</option>
                                                                    <option>الجار</option>
                                                                    <option>فاعل خير</option>
                                                                </select>                                                            
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>هل يتولى العائل أفراد آخرين</strong></label>
                                                                <select class="form-control"  name="other_person">
                                                                    <option><?php echo e($information['other_person']); ?></option>
                                                                    <option>نعم</option>
                                                                    <option>لا</option>
                                                                </select> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>عدد الأفراد الذي يتولى العائل أمرهم</strong></label>
                                                                <select class="form-control"  name="other_person_num">
                                                                    <option><?php echo e($information['other_person_num']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                      
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>لماذا يتولى العائل أمرهم</strong></label>
                                                                <input type="text" name="other_person_reason"  value="<?php echo e($information['other_person_reason']); ?>" class="form-control"> 
                                                            </div>
                                                        </div>
                                                    </div>


                                                    <label><strong>عدد الدارسين من أفراد الأسرة</strong></label>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>المرحلة الإبتدائية</strong></label>
                                                                <select class="form-control"  name="primary_school">
                                                                    <option><?php echo e($information['primary_school']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                     
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>المرحلة المتوسطة</strong></label>
                                                                <select class="form-control"  name="middle_school">
                                                                    <option><?php echo e($information['middle_school']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                            
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>المرحلة الثانوية</strong></label>
                                                                <select class="form-control"  name="middle_school">
                                                                    <option><?php echo e($information['middle_school']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                     
                                                            </div>
                                                        </div> 
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong>المرحلة الجامعية</strong></label>
                                                                <select class="form-control"  name="university">
                                                                    <option><?php echo e($information['university']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                            
                                                            </div>
                                                        </div>
                                                    </div>
                                
                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong> الخريجين</strong></label>
                                                                <select class="form-control" name="graduated">
                                                                    <option><?php echo e($information['graduated']); ?></option>
                                                                    <option>0</option>
                                                                    <option>1</option>
                                                                    <option>2</option>
                                                                    <option>3</option>
                                                                    <option>4</option>
                                                                    <option>5</option>
                                                                    <option>6</option>
                                                                </select>                                                    
                                                            </div>
                                                        </div> 
                                                    </div>

                                                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">المعلومات الصحية </h5>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label><strong> الحالة الصحية لمقدم الطلب</strong></label>
                                                                <select class="form-control"  name="disease">
                                                                    <option><?php echo e($information['disease']); ?></option>
                                                                    <option>سليم</option>
                                                                    <option>أمراض القلب</option>
                                                                    <option>أمراض السكري</option>
                                                                    <option>ارتفاع ضغط الدم</option>
                                                                    <option>إعاقة بصرية أو سمعية/حركية</option>
                                                                    <option>آخرى</option>
                                                                </select>                                                   
                                                            </div>
                                                        </div> 
                                                    </div>

                                                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                        <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">المصابون بأمراض من أفراد العائلة</h5>
                                                    </div>

                                                    <div class="form-row">
                                                        <div class="col">
                                                            <div class="form-group">

                                                               <div class="input-group control-group2 increment_form">
                                                                        <label> اسم المريض </label>
                                                                            <input name="disease_informations[]" type="text" class="form-control">

                                                                        <label> اسم المرض </label>
                                                                            <input  name="disease_informations[]" type="text" class="form-control">

                                                                        <label> تاريخ المرض </label>
                                                                            <input name="disease_informations[]" type="date" class="form-control">
                                                                        
                                                                        <label><strong>جنس المريض</strong></label>
                                                                            <select type="text" name="disease_informations[]" class="form-control">
                                                                                    <option value=""></option>
                                                                                    <option value="ذكر"
                                                                                    >ذكر</option>
                                                                                    <option value="أنثى"
                                                                                    >أنثى</option>
                                                                            </select>
                                                                        <label><strong>صلة قرابة المريض بمقدم الطلب:</strong></label>
                                                                            <select class="form-control" name="disease_informations[]">
                                                                                <option></option>
                                                                                <option>والد</option>
                                                                                <option>والدة</option>
                                                                                <option>زوج</option>
                                                                                <option>زوجة</option>
                                                                                <option>ابن</option>
                                                                                <option>جد</option>
                                                                                <option>جدة</option>
                                                                                <option>أخ</option>
                                                                                <option>أخت</option>
                                                                                <option>ابن الإبن</option>
                                                                                <option>عم</option>
                                                                                <option>عمة</option>
                                                                                <option>خال</option>
                                                                                <option>خالة</option>
                                                                                <option>ابن الأخ</option>
                                                                                <option>ابن الأخت</option>
                                                                                <option>الجار</option>
                                                                                <option>فاعل خير</option>
                                                                            </select>

                                                                        <div class="input-group-btn2"> 
                                                                            <button class="btn-s" type="button"><i class="glyphicon glyphicon-plus"></i>إضافة مريض </button>
                                                                        </div>
                                                                </div>
                                                            
                                                            <div class="clone_form">
                                                                <div class="input-group control-group2 increment2">
                                                                    <label> اسم المريض </label>
                                                                        <input name="disease_informations[]" type="text" class="form-control">

                                                                    <label> اسم المرض </label>
                                                                        <input name="disease_informations[]" type="text" class="form-control">

                                                                    <label> تاريخ المرض </label>
                                                                        <input name="disease_informations[]" type="date" class="form-control">
                                                                    
                                                                    <label><strong>جنس المريض</strong></label>
                                                                        <select type="text" name="disease_informations[]" class="form-control">
                                                                                <option value=""></option>
                                                                                <option value="ذكر"
                                                                                >ذكر</option>
                                                                                <option value="أنثى"
                                                                                >أنثى</option>
                                                                        </select>
                                                                    <label><strong>صلة قرابة المريض بمقدم الطلب:</strong></label>
                                                                        <select class="form-control" name="disease_informations[]">
                                                                            <option></option>
                                                                            <option>والد</option>
                                                                            <option>والدة</option>
                                                                            <option>زوج</option>
                                                                            <option>زوجة</option>
                                                                            <option>ابن</option>
                                                                            <option>جد</option>
                                                                            <option>جدة</option>
                                                                            <option>أخ</option>
                                                                            <option>أخت</option>
                                                                            <option>ابن الإبن</option>
                                                                            <option>عم</option>
                                                                            <option>عمة</option>
                                                                            <option>خال</option>
                                                                            <option>خالة</option>
                                                                            <option>ابن الأخ</option>
                                                                            <option>ابن الأخت</option>
                                                                            <option>الجار</option>
                                                                            <option>فاعل خير</option>
                                                                        </select>
                                                                        <div class="input-group-btn"> 
                                                                            <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> حذف</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <div class="card-header py-3" style="background: rgb(255,255,255);">
                                                                <h5 class="m-0 font-weight-bold" style="color: #006837;text-align: center;">معلومات السكن </h5>
                                                            </div>

                                                            <div class="form-row">
                                                                <div class="col">
                                                                    <div class="form-group">
                                                                        <label><strong> موقع السكن</strong></label>
                                                                        <input type="text" name="place" class="form-control" value="<?php echo e($home_info['place']); ?>">
                                                                    </div>
                                                                </div>
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>وصف السكن</strong></label>
                                                                            <input type="text" name="description" class="form-control" value="<?php echo e($home_info['description']); ?>">                                                   
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>رقم المبنى</strong></label>
                                                                            <input type="text" name="building_num" class="form-control" value="<?php echo e($home_info['building_num']); ?>">                         
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>نوع السكن</strong></label>
                                                                            <select class="form-control" name="building_type">
                                                                                <option><?php echo e($home_info['building_type']); ?></option>
                                                                                <option>فيلا</option>
                                                                                <option>دور</option>
                                                                                <option>بيت شعبي</option>
                                                                                <option>شقة</option>
                                                                            </select>                                                       
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ملكية السكن</strong></label>
                                                                            <select class="form-control" name="building_ownership">
                                                                                <option><?php echo e($home_info['building_ownership']); ?></option>
                                                                                <option>ملك</option>
                                                                                <option>مستأجر</option>
                                                                                <option>وقف</option>
                                                                            </select>                         
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>احداثيات السكن(E)</strong></label>
                                                                            <input type="text" name="location_E" class="form-control" value="<?php echo e($home_info['location_E']); ?>">                                                   
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>احداثيات السكن(N)</strong></label>
                                                                            <input type="text" name="location_N" class="form-control" value="<?php echo e($home_info['location_N']); ?>">
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>قيمة الإيجار(في حال كان مستأجر)</strong></label>
                                                                            <input type="integer" name="building_rent" class="form-control" value="<?php echo e($home_info['building_rent']); ?>">
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>هل قيمة الإيجار مناسبة للسكن؟</strong></label>
                                                                            <select class="form-control" name="rent_evaluate">
                                                                                <option><?php echo e($home_info['rent_evaluate']); ?></option>
                                                                                <option>نعم</option>
                                                                                <option>لا</option>
                                                                                <option>غير مستأجر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                </div>
                                                                
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكونات السكن</strong></label>
                                                                            <br>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="غرفة نوم">
                                                                                    غرفة نوم
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="صالة">
                                                                                    صالة
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="حوش">
                                                                                    حوش
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="مجلس">
                                                                                    مجلس
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="مطبخ">
                                                                                    مطبخ
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="غرفة سائق">
                                                                                    غرفة سائق
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="ملحق خارجي">
                                                                                    ملحق خارجي
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="صالة طعام">
                                                                                    صالة طعام
                                                                                </label>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="home_category[]" type="checkbox" value="مستودع">
                                                                                    مستودع
                                                                                </label>
                                                                        </div>
                                                                    </div> 
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>عدد جميع الغرف بالمنزل</strong></label>
                                                                            <select class="form-control" name="room_number_all">
                                                                                <option><?php echo e($home_info['room_number_all']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                                <option>6</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>هل عدد الغرف كافية لأفراد الأسرة</strong></label>
                                                                            <select class="form-control" name="room_number">
                                                                                <option><?php echo e($home_info['room_number']); ?></option>
                                                                                <option>نعم</option>
                                                                                <option>لا</option>
                                                                            </select>                                                                        
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>هل وضع المنزل مناسب للسكن</strong></label>
                                                                            <select class="form-control" name="home_status">
                                                                                <option><?php echo e($home_info['home_status']); ?></option>
                                                                                <option>نعم</option>
                                                                                <option>لا</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>اذا كان غير مناسب اذكر السبب</strong></label>
                                                                            <input type="text" class="form-control" name="status_reason" value="<?php echo e($home_info['status_reason']); ?>">                                                                       
                                                                        </div>
                                                                    </div>
                                                                </div>



                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ماهو تقييمك لجودة السكن</strong></label>
                                                                            <select class="form-control" name="home_quality">
                                                                                <option><?php echo e($home_info['home_quality']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>5</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                </div>

                                                                <label><strong>ماهو تقييمك لحالة السكن(البنيةالأساسية)</strong></label>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>غرفة النوم</strong></label>
                                                                            <select class="form-control" name="bedroom_evaluate">
                                                                                <option><?php echo e($home_info['bedroom_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مطبخ</strong></label>
                                                                            <select class="form-control" name="kitchen_evaluate">
                                                                                <option><?php echo e($home_info['kitchen_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>دورات مياة</strong></label>
                                                                            <select class="form-control" name="bathroom_evaluate">
                                                                                <option><?php echo e($home_info['bathroom_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مستودع</strong></label>
                                                                            <select class="form-control" name="store_evaluate">
                                                                                <option><?php echo e($home_info['store_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>غرفة سائق</strong></label>
                                                                            <select class="form-control" name="driverroom_evaluate">
                                                                                <option><?php echo e($home_info['driverroom_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>حوش</strong></label>
                                                                            <select class="form-control" name="outdoor_evaluate">
                                                                                <option><?php echo e($home_info['outdoor_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>سطح </strong></label>
                                                                            <select class="form-control" name="roof_evaluate">
                                                                                <option><?php echo e($home_info['roof_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ملحق خارجي</strong></label>
                                                                            <select class="form-control" name="annex_evaluate">
                                                                                <option><?php echo e($home_info['annex_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>صالة </strong></label>
                                                                            <select class="form-control" name="hall_evaluate">
                                                                                <option><?php echo e($home_info['hall_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مجلس </strong></label>
                                                                            <select class="form-control" name="living_room_evaluate">
                                                                                <option><?php echo e($home_info['living_room_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>صالة طعام </strong></label>
                                                                            <select class="form-control" name="dining_room_evaluate">
                                                                                <option><?php echo e($home_info['dining_room_evaluate']); ?></option>
                                                                                <option>تصدعات</option>
                                                                                <option>هبوط</option>
                                                                                <option>خطر</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>إلى ماذا يحتاج السكن</strong></label>
                                                                            <br>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value=" أعمال كهربائية">
                                                                                أعمال كهربائية
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="أعمال سباكة">
                                                                                أعمال سباكة
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="مطبخ">
                                                                                مطبخ
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="أبواب">
                                                                                أبواب
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="حنفيات">
                                                                                حنفيات
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="شبابيك">
                                                                                شبابيك
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="صرف صحي">
                                                                                صرف صحي
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="دهانات">
                                                                                دهانات
                                                                            </label>
                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="تلبيس">
                                                                                تلبيس
                                                                            </label>

                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="لمبات">
                                                                                لمبات
                                                                            </label>

                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="سخانات">
                                                                                سخانات
                                                                            </label>

                                                                            <label class="checkbox-inline">
                                                                                <input name="category[]" type="checkbox" value="شفاطات هواء">
                                                                                شفاطات هواء
                                                                            </label>  
                                                                        </div>
                                                                    </div> 
                                                                </div>
                                                                <label><strong>الأجهزة الكهربائية</strong></label>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف سبيليت </strong></label>
                                                                            <select class="form-control" name="conditioner_1">
                                                                                <option><?php echo e($home_info['conditioner_1']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف شبك </strong></label>
                                                                            <select class="form-control" name="conditioner_2">
                                                                                <option><?php echo e($home_info['conditioner_2']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف صحراوي </strong></label>
                                                                            <select class="form-control" name="conditioner_3">
                                                                                <option><?php echo e($home_info['conditioner_3']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ثلاجة </strong></label>
                                                                            <select class="form-control" name="refrigerator">
                                                                                <option><?php echo e($home_info['refrigerator']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>فريزر </strong></label>
                                                                            <select class="form-control" name="fraser">
                                                                                <option><?php echo e($home_info['fraser']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>برادة ماء</strong></label>
                                                                            <select class="form-control" name="water_cooler">
                                                                                <option><?php echo e($home_info['water_cooler']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>غسالة </strong></label>
                                                                            <select class="form-control" name="washing_machine">
                                                                                <option><?php echo e($home_info['washing_machine']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>سخانة</strong></label>
                                                                            <select class="form-control" name="heater">
                                                                                <option><?php echo e($home_info['heater']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكنسة كهرب </strong></label>
                                                                            <select class="form-control" name="cleaner">
                                                                                <option><?php echo e($home_info['cleaner']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>دفاية</strong></label>
                                                                            <select class="form-control" name="fireplace">
                                                                                <option><?php echo e($home_info['fireplace']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مروحة شفط </strong></label>
                                                                            <select class="form-control" name="fan">
                                                                                <option><?php echo e($home_info['fan']); ?></option>
                                                                                <option>1</option>
                                                                                <option>2</option>
                                                                                <option>3</option>
                                                                                <option>4</option>
                                                                                <option>أكثر</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ماهي الأجهزة الكهربائيةالغير متوفرة </strong></label>
                                                                            <br>
                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="مكيف سبيليت">
                                                                                    مكيف سبيليت            
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="مكيف شبك">
                                                                                    مكيف شبك
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="مكيف صحراوي">
                                                                                    مكيف صحراوي
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="ثلاجة">
                                                                                    ثلاجة            
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="برادة ماء">
                                                                                    برادة ماء
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="غسالة">
                                                                                    غسالة
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="سخانة">
                                                                                    سخانة
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="مكنسة كهرب">
                                                                                    مكنسة كهرب
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="دفاية">
                                                                                    دفاية
                                                                                </label>

                                                                                <label class="checkbox-inline">
                                                                                    <input name="electric[]" type="checkbox" value="مروحة شفط">
                                                                                    مروحة شفط
                                                                                </label>
                                                                        </div>
                                                                    </div> 
                                                                </div>



                                                                <label><strong>ماهو تقييمك لحالة الأجهزه الكهربائية</strong></label>


                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف سبيليت</strong></label>
                                                                            <select name="conditioner_2_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['conditioner_2_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف شبك</strong></label>
                                                                            <select name="conditioner_1_evaluate" class="form-control" >
                                                                                <option><?php echo e($home_info['conditioner_1_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكيف صحراوي</strong></label>
                                                                            <select name="conditioner_3_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['conditioner_3_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>ثلاجة </strong></label>
                                                                            <select name="refrigerator_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['refrigerator_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>فريزر </strong></label>
                                                                            <select name="fraser_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['fraser_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>برادة ماء</strong></label>
                                                                            <select name="water_cooler_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['water_cooler_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>غسالة </strong></label>
                                                                            <select name="washing_machineـevaluate" class="form-control">
                                                                                <option><?php echo e($home_info['washing_machineـevaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>سخانة</strong></label>
                                                                            <select name="heater_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['heater_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مكنسة كهرب </strong></label>
                                                                            <select name="cleaner_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['cleaner_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>دفاية</strong></label>
                                                                            <select name="fireplace_evaluate" class="form-control">
                                                                                <option><?php echo e($home_info['fireplace_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>مروحة شفط </strong></label>
                                                                            <select name="fan_evaluate" class="form-control" name="">
                                                                                <option><?php echo e($home_info['fan_evaluate']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                </div>

                                                                <div class="form-row">
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong> ماهو تقييمك لحالة الأثاث </strong></label>
                                                                            <select class="form-control" name="evaluate_furniture">
                                                                                <option><?php echo e($home_info['evaluate_furniture']); ?></option>
                                                                                <option>غير متوفر</option>
                                                                                <option>بحاجة إلى تغيير</option>
                                                                                <option>بحاجة إلى صيانة</option>
                                                                                <option>مقبول</option>
                                                                                <option>ممتاز</option>
                                                                            </select>
                                                                        </div>
                                                                    </div> 
                                                                    <div class="col">
                                                                        <div class="form-group">
                                                                            <label><strong>هل المجالس مؤثثة؟</strong></label>
                                                                            <select class="form-control" name="furnished">
                                                                                <option><?php echo e($home_info['furnished']); ?></option>
                                                                                <option>نعم</option>
                                                                                <option>لا</option>
                                                                            </select>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                    
                                                         
                                                    

                                                   
                                                    




                                                    

                                                    
                                                        
                                                        
                                                    <div class="form-group"><button style="background-color:#006837; color:white;" class="btn btns mt-4" type="submit">حفظ</button></div>
                                            </div>
                                        </div>
                            </form>
                        </div>
                    </div>
                </div>
   




<script>
    $(document).ready(function(){

    var count = 1;

    dynamic_field(count);

    function dynamic_field(number)
    {
    html = '<tr>';
            html += '<td><input type="text" name="children_informations[]" class="form-control" /></td>';
            html += '<td><select type="select" id="gender" name="children_informations[]">';
            html += '<option value=""></option>'
            html += '<option value="male">ذكر</option>'
            html += '<option value="female">أنثى</option>'
            html += '</select></td>';
            html += '<td><input type="text" name="children_informations[]" class="form-control" /></td>';
            html += '<td><input type="date" id="" name="children_informations[]" class="dob" /></td>';

            if(number > 1)
            {
                html += '<td><button type="button" name="remove" id="" class="btn btn-danger remove">حذف</button></td></tr>';
                $('tbody').append(html);
            }
            else
            {   
                html += '<td><button type="button" name="add" id="add"  style="background-color:#006837; color:white;" class="btn">إضافة</button></td></tr>';
                $('tbody').html(html);
            }
    }

    $(document).on('click', '#add', function(){
        count++;
        dynamic_field(count);
    });

    $(document).on('click', '.remove', function(){
        count--;
        $(this).closest("tr").remove();
    });

    $('#dynamic_form').on('submit', function(event){
            event.preventDefault();
            $.ajax({
                url:'',
                method:'post',
                data:$(this).serialize(),
                dataType:'json',
               
                success:function(data)
                {
                    if(data.error)
                    {
                        var error_html = '';
                        for(var count = 0; count < data.error.length; count++)
                        {
                            error_html += '<p>'+data.error[count]+'</p>';
                        }
                        $('#result').html('<div class="alert alert-danger">'+error_html+'</div>');
                    }
                    else
                    {
                        dynamic_field(1);
                        $('#result').html('<div class="alert alert-success">'+data.success+'</div>');
                    }
                    $('#save').attr('disabled', false);
                }
            })
    });

    });
   
</script>

<script>
    $(document).ready(function(){
        $("#gender").change(function(){
           var gender_value = $("#gender").val();

        $("input.dob").change(function(){
           var value = $(".dob").val();
            var dob = new Date(value);
            var today = new Date();
            var age = Math.floor((today-dob) / (365.25 * 24 * 60 * 60 * 1000));
            if(isNaN(age)) {
            // will set 0 when value will be NaN
                age=0;
            }
            else{
                age=age;
            }

            if ((age > 30) && (gender_value="female")){
                alert(' يجب أن يكون العمر للأنثى أقل من 30 ');
                $("input[type=date]").val(""); 
            }else if ((age > 25) && (gender_value="male")){
                alert(' يجب أن يكون العمر للذكر أقل من 25 ');
                $("input[type=date]").val("");
            }
        });
        });
    });
</script>

<script type="text/javascript">

    $(document).ready(function() {
      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/profile/edit.blade.php ENDPATH**/ ?>