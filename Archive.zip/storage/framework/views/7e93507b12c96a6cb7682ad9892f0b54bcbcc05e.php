<?php $__env->startSection('content'); ?>




<div class="alert alert-danger text-center" role="alert">
المستفيد لم يقم بإضافة أي بيانات 
</div>


<form action=" <?php echo e(route('committee.dashboard')); ?>" class="text-right" method="get">
    <button type="submit" class="btn btn-primary">رجوع</button>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('benefits.committee.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/committee/error.blade.php ENDPATH**/ ?>