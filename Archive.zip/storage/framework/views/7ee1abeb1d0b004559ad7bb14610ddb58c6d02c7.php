<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'معلومات الإتصال'); ?>


<body style="background-image: url(<?php echo e(url('/img/خلفيه%20البرنامج%205%20شفاف.png')); ?>); font-family:Cairo;">
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="<?php echo e(('/img/شعار%20شفاف.png')); ?>"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">معلومات التواصل</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <form action="<?php echo e(route('contactInfo.store')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="email">
                                                <strong>البريد الألكتروني</strong><br>
                                        </label>
                                        <input class="form-control" type="email" name="email"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="mobile_number"><strong>رقم الجوال</strong></label><input class="form-control" type="text" name="mobile_number"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="phone_number"><strong>رقم الهاتف</strong><br></label><input class="form-control" type="text" name="phone_number"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="whatsapp_number"><strong>رقم الجوال (واتساب)</strong></label><input class="form-control" type="text" name="whatsapp_number"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="other_number"><strong>رقم جوال قريب</strong><br></label><input class="form-control" type="text" name="other_number"></div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="teljob">
                                            <strong>صلة القرابة</strong></label>
                                            <select class="form-control" name="relative">
                                                <option></option>
                                                <option>والد</option>
                                                <option>والدة</option>
                                                <option>زوج</option>
                                                <option>زوجة</option>
                                                <option>ابن</option>
                                                <option>جد</option>
                                                <option>جدة</option>
                                                <option>أخ</option>
                                                <option>أخت</option>
                                                <option>ابن الإبن</option>
                                                <option>عم</option>
                                                <option>عمة</option>
                                                <option>خال</option>
                                                <option>خالة</option>
                                                <option>ابن الأخ</option>
                                                <option>ابن الأخت</option>
                                            </select></div>
                                    </div>
                                </div>
                                <div class="form-group"><button class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;">حفظ</button>
                                <a href="<?php echo e(route('jobInfo.create')); ?>" class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;">التالي<i class="fa fa-arrow-left"></i></a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/sundus/Desktop/vagrantpro/webserv/laravel_pro_main/resources/views/benefits/contact/create.blade.php ENDPATH**/ ?>