<?php

namespace Database\Factories;

use App\Models\commitments;
use Illuminate\Database\Eloquent\Factories\Factory;

class commitmentsFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = commitments::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
