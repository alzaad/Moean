<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInformationTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('information', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')
            	->references('id')
                ->on('users');

            $table->string('disease');//هل تشكو من أمراض
            $table->string('disease_informations'); //علومات المريض
           
            $table->string('social_status');//الحالة الإجتماعية
        
            $table->string('family_number');//عدد أفراد الأسرة
            $table->string('wife_number');//عدد الزوجات
            $table->string('male_number');//عدد الذكور
            $table->string('female_number');//الإناث
            $table->string('children_informations');//معلومات الأبناء

            $table->string('who_spend');//من يتولى الإنفاق على الأسرة

            $table->string('other_person');//هل يتولى العائل أفراد آخرين
            $table->string('other_person_num');//عدد الأفراد الذي يتولى العائل امرهم
            $table->string('other_person_reason');//لماذا يتولى أمرهم

            $table->string('primary_school');//اعداد الدارسين بالمرحلة الإبتدائية
            $table->string('middle_school');//المرحلة المتوسطة
            $table->string('high_school');// المرحلة الثانوية
            $table->string('university');// الجامعية
            $table->string('graduated');//الخريجين
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('information');
    }
}
