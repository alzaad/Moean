<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLocationInfosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('location_infos', function (Blueprint $table) {
            
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->foreign('user_id')
            	->references('id')
                ->on('users');

            $table->string('place');//موقع السكن
            $table->string('description');//وصف السكن
            $table->string('building_num');//رقم المبنى
            $table->string('building_type');//نوع السكن
            $table->string('building_ownership');//ملكية السكن
            $table->integer('building_rent');//قيمة الإيجار
            $table->string('location_N');//احداثيات السكن
            $table->string('location_E');//احداثيات السكن
            $table->string('rent_evaluate');//قيمة الإيجار

            $table->string('room_number_all');//عدد جميع الغرف
            $table->string('room_number');//هل عدد الغرف كافية
            $table->string('home_status');//هل المنزل مناسب للسكن
            $table->string('status_reason')->nullable();// السبب اذا كان المنزل غير مناسب
            $table->string('home_quality');//جودة السكن

            $table->string('bedroom_evaluate');//تقييم حالة النوم
            $table->string('kitchen_evaluate');//تقييم حالة المطبخ
            $table->string('bathroom_evaluate');//تقييم حالة دورات المياة
            $table->string('store_evaluate');//تقييم حالة المستودع
            $table->string('driverroom_evaluate');//تقييم غرفة السائق
            $table->string('hall_evaluate');//تقييم حالة الصالة
            $table->string('dining_room_evaluate');//تقييم غرفة الطعام
            $table->string('living_room_evaluate');//تقييم المجلس
            $table->string('roof_evaluate');//تقييم السطح
            $table->string('annex_evaluate');//تقييم الملحق الخارجي
            $table->string('outdoor_evaluate');//تقييم حالة الحوش

            $table->string('evaluate_furniture');//تقييم حالة الأثاث
            $table->string('furnished');// هل الغرف مؤثثة

            $table->string('washing_machine');//غسالة
            $table->string('conditioner_1');//عدد مكيفات الشبك
            $table->string('conditioner_2');//عدد مكيفات السبيليت
            $table->string('conditioner_3');//عدد مكيفات الصحراوي
            $table->string('refrigerator');//عدد الثلاجات
            $table->string('fraser');//عدد الفريزر
            $table->string('cleaner');//عدد مكنسة الكهرب
            $table->string('heater');//عدد السخانات
            $table->string('fan');//عدد المراوح
            $table->string('fireplace');//عدد الدفايات
            $table->string('water_cooler');//برادة ماء
            //تقييم
            $table->string('washing_machineـevaluate');//غسالة تقييم
            $table->string('conditioner_1_evaluate');// مكيفات الشبك تقييم
            $table->string('conditioner_2_evaluate');// مكيفات السبيليت تقييم
            $table->string('conditioner_3_evaluate');// مكيفات الصحراوي تقييم
            $table->string('refrigerator_evaluate');// الثلاجات تقييم
            $table->string('fraser_evaluate');// الفريزر تقييم
            $table->string('cleaner_evaluate');// مكنسة الكهرب تقييم
            $table->string('heater_evaluate');// السخانات تقييم
            $table->string('fan_evaluate');// المراوح تقييم
            $table->string('fireplace_evaluate');// الدفايات تقييم
            $table->string('water_cooler_evaluate');//برادة ماء تقييم
            
            $table->string('category');//إلى ماذا يحتاج السكن
            $table->string('home_category');//مكونات السكن
            $table->string('electric');//ماهي الأجهزه الغير مترفرة

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('location_infos');
    }
}
