<?php

namespace App\Http\Controllers;

use App\Models\InitialStudy;
use Illuminate\Http\Request;

class InitialStudyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('benefits.first.initial_study');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('benefits.first.initial_study');

    }
    
    public function check_initialstudy(Request $request)
    {

        $this->validate($request, [
            'family' => 'required',
            'wife' => 'required',
            'males' => 'required',
            'females' => 'required',
            'salary' => 'required',
            'social_security' => 'required',
        ]);


        $family = $request['family'];
        $wife = $request['wife'];
        $males = $request['males'];
        $females = $request['females'];
        $salary = $request['salary'];
        $social_security = $request['social_security'];
        $other = $request['other'];
        $category = "";

        //Check category
        if($family >= 12){
            $category ='أ';
            // print_r($category);
        }elseif ($family >= 7) {
            $category ='ب';
            // print_r($category);
        }elseif ($family >= 2) {
            $category ='ج';
            // print_r($category);
        }else{
            $category ='د';
            // print_r($category);
        }

        //calculate
        //مصروف الكهرب 
        //مصروف الهاتف
        //مصروفات آخرى
        //مصروف الأبناء = عدد الأبناء*200
        //مصروف البنات=عدد البنات*200
        //مصروف الزوجات = عددالزوجات *300 
        //مصروفات طارئة
        //مصروف المواد الغذائية

        if($category == 'أ'){
            $result = (($wife*300)+($females*200)+($males*200)+($other*150)+ 800 + 250 + 400 + 250);
            $final_result = $result - 6000;
            if($final_result >= 1200){
                $request->session()->flash('message.level', 'danger');
                $request->session()->flash('message.content', 'غير مستحق، لأنه تجاوز الحد المسموح من صافي الدخل الشهري');
            }else{
                return view('benefits.first.success');
                // $request->session()->flash('message.level', 'success'); 
                // $request->session()->flash('message.content', 'مستحق،الرجاء اكمال تعبئة البيانات');
            }
        }elseif ($category == 'ب'){
            $result = (($wife*300)+($females*200)+($males*200)+($other*150)+ 700 + 700 + 200 + 200);
            $final_result = $result - 4000;
            if($final_result >= 1000){
                $request->session()->flash('message.level', 'danger');
                $request->session()->flash('message.content', 'غير مستحق، لأنه تجاوز الحد المسموح من صافي الدخل الشهري');
            }else{
                return view('benefits.first.success');
                // $request->session()->flash('message.level', 'success'); 
                // $request->session()->flash('message.content', 'مستحق،الرجاء اكمال تعبئة البيانات');

            }
        }elseif ($category == 'ج'){
            $result = (($wife*300)+($females*200)+($males*200)+($other*150)+ 600 + 150 + 150 + 450);
            $final_result = $result - 3000;
            if($final_result >= 700){
                $request->session()->flash('message.level', 'danger');
                $request->session()->flash('message.content', 'غير مستحق، لأنه تجاوز الحد المسموح من صافي الدخل الشهري');
            }else{
                return view('benefits.first.success');
                // $request->session()->flash('message.level', 'success'); 
                // $request->session()->flash('message.content', 'مستحق،الرجاء اكمال تعبئة البيانات');
            }
        }else{
            $result = (($wife*300)+($females*200)+($males*200)+($other*150)+ 500 + 100 + 300 + 250);
            $final_result = $result - 2000;
            if($final_result >= 300){
                $request->session()->flash('message.level', 'danger');
                $request->session()->flash('message.content', 'غير مستحق، لأنه تجاوز الحد المسموح من صافي الدخل الشهري');
            }else{
                return view('benefits.first.success');
                // $request->session()->flash('message.level', 'success'); 
                // $request->session()->flash('message.content', 'مستحق،الرجاء اكمال تعبئة البيانات');
            }
        }
        return back();
    }


    public function checkLocation(){

        return view('benefits.first.location');
    }

    public function check_Location(Request $request){

        $location = $request['check_location'];
        // dd($location);
        if($location == 'آخرى'){
            return view('benefits.first.error');

        }else{
            return view('benefits.first.initial_study');

        }
       
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
    //    dd($request->all());
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\InitialStudy  $initialStudy
     * @return \Illuminate\Http\Response
     */
    public function show(InitialStudy $initialStudy)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\InitialStudy  $initialStudy
     * @return \Illuminate\Http\Response
     */
    public function edit(InitialStudy $initialStudy)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\InitialStudy  $initialStudy
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, InitialStudy $initialStudy)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\InitialStudy  $initialStudy
     * @return \Illuminate\Http\Response
     */
    public function destroy(InitialStudy $initialStudy)
    {
        //
    }
}
