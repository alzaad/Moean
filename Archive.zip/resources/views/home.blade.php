@extends('layouts.app')
@section('content')
@section('title', 'الصفحة الرئيسية')



@endsection
@section('footer')
    @include('footer')
@endsection