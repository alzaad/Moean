@extends('benefits.committee.header')
@section('content')




<div class="alert alert-danger text-center" role="alert">
المستفيد لم يقم بإضافة أي بيانات 
</div>


<form action=" {{ route('committee.dashboard') }}" class="text-right" method="get">
    <button type="submit" class="btn btn-primary">رجوع</button>
</form>
@endsection

@section('footer')
    @include('footer')
@endsection