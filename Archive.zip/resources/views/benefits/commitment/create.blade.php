@extends('layouts.app')
@section('content')
@section('title', 'الإفصاح عن الإلتزامات')

<body style="background-image: url({{url('/img/خلفيه%20البرنامج%205%20شفاف.png')}}); font-family:Cairo;">
    
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="{{('/img/شعار%20شفاف.png')}}"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">الإفصاح عن الإلتزامات</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li class="alert alert-danger text-right">{{ $error }}</li>
                                @endforeach
                            </ul>
                            <form action="{{ route('commitment.store') }}" class="text-center" method="POST">
                                @csrf
                        
                                <div class="form-row text-right">
                                    <div class="col">
                                        <div class="form-group"><label for=""><strong>ايجار سنوي</strong><br></label><input name="rent_home" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>متوسط فاتورة الكهرباء (شهرياً)</strong><br></label><input name="electricity_bill" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>متوسط فاتورة الماء (شهرياً)</strong><br></label><input name="water_bill" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>قسط الصندوق العقاري (اقساط شهرية)</strong><br></label><input  name="monthly_fees" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>قسط بنك التنمية الإجتماعية&nbsp;(اقساط شهرية)</strong><br></label><input name="monthly_fees_eco_bank" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>قسط البنك التجاري&nbsp;(اقساط شهرية)&nbsp;</strong><br></label><input name="monthly_fees_bank" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>ديون شخصية</strong><br></label><input name="personal_debts" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>مستلزمات المواليد والأطفال (إجمالي المصروفات الشهرية)</strong><br></label><input name="supplies" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>عيادات ومستوصفات أهلية (إجمالي المصروفات الشهرية)&nbsp;</strong><br></label><input name="hospital" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>إجمالي مصروفات التنقل (شهريا)</strong><br></label><input name="transfer" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>تعبئة البنزين او الديزل وتغيير الزيت (إجمالي المصروفات الشهرية)</strong><br></label><input name="gas" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>صيانة أعطال السيارة&nbsp; (إجمالي المصروفات الشهرية)</strong><br></label><input name="maintenance" class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>هل لديك أي أعباء مالية او ديون اخرى</strong><br></label><select name="debts" class="form-control"><optgroup label="   "><option></option><option>نعم</option><option>لا</option></optgroup></select></div>
                                        <div
                                            class="form-group"><label for=""><strong>الديون الاخرى (ان وجدت)&nbsp;</strong><br></label><input name="debts_info" class="form-control" type="text"></div>
                                </div>
                        </div>
                        <div class="form-group">
                            <button class="btn btns mt-4" type="submit" style="background-color:#006837; color:white; float: right;">حفظ</button>
                            <a href="{{ route('location.create') }}" type="button"  class="btn btns mt-4" style="background-color:#006837; color:white; float: right;">{{__('التالي')}}<i class="fa fa-arrow-left"></i></a>

                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
   
@endsection

@section('footer')
    @include('footer')
@endsection