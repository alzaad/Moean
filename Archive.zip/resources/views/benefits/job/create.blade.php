
@extends('layouts.app')
@section('content')
@section('title', 'معلومات المهنة')

<body style="background-image: url({{url('/img/خلفيه%20البرنامج%205%20شفاف.png')}}); font-family:Cairo;">    
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="{{('/img/شعار%20شفاف.png')}}"></div>
    </nav>
    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">معلومات المهنة</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            @if (count($errors) > 0)
                                <div class = "alert alert-danger text-right">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                                </div>
                            @endif
                            <form method="POST" action="{{ route('jobInfo.store') }}">
                                @csrf
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="job"><strong>المهنة</strong><br></label>
                                            <select class="form-control" name="job">
                                                <option></option>
                                                <option>موظف/ة حكومي/ة</option>
                                                <option>موظف/ة أهلي/ة</option>
                                                <option>متقاعد/ة</option>
                                                <option>متسبب/ة</option>
                                                <option>طالب/ة</option>
                                                <option>ربة منزل</option>
                                                <option>لايوجد</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="salary"><strong>مصدر الدخل</strong></label>
                                            <select name="salary" class="form-control">
                                                <optgroup label="  ">
                                                    <option></option>
                                                    <option value="12">راتب شهري (قطاع عسكري /حكومي)</option>
                                                    <option value="13">راتب شهري (قطاع خاص)</option>
                                                    <option value="14">راتب تقاعد (قطاع خاص)</option>
                                                    <option value="15">الضمان الإجتماعي</option>
                                                    <option value="16">إعانة سنوية </option>
                                                    <option value="17">نشاط تجاري</option>
                                                    <option value="18">غير ذلك</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="salary_month"><strong>الراتب الشهري</strong><br></label>
                                            <input class="form-control" type="text" name="salary_month">
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="phone_number"><strong>هاتف العمل</strong></label><input class="form-control" type="text" name="phone_number"></div>
                                    </div>
                                </div>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for="salary"><strong>التعليم</strong></label>
                                            <select name="education" class="form-control">
                                                <optgroup label="  ">
                                                    <option></option>
                                                    <option value="12">جامعي</option>
                                                    <option value="13">ثانوي</option>
                                                    <option value="14">متوسط</option>
                                                    <option value="15">ابتدائي</option>
                                                    <option value="16">يقرأويكتب </option>
                                                    <option value="17">أمي</option>
                                                </optgroup>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group"><label for="job_place"><strong>مكان العمل</strong><br></label><input class="form-control" type="text" name="job_place"></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <button class="btn btns mt-4" type="submit" style="background-color:#006837; color:white;">حفظ</button>
                                    <a href="{{route('information.create')}}" class="btn btns mt-4" style="background-color:#006837; color:white;" type="submit">التالي<i class="fa fa-arrow-left"></i></a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('footer')
    @include('footer')
@endsection