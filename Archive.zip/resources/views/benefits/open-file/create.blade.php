
@extends('layouts.app')
@section('content')
@section('title', 'فتح ملف')



<body style="background-image: url({{url('/img/خلفيه%20البرنامج%205%20شفاف.png')}}); font-family:Cairo;">
    
    <nav class="navbar navbar-light navbar-expand-md navigation-clean">
        <div class="container"><img class="mx-auto logosize" src="{{('/img/شعار%20شفاف.png')}}"></div>
    </nav>


    <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">فتح ملف</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            @if (count($errors) > 0)
                            <div class="alert alert-danger text-right">
                              <strong>خطأ!</strong> حدث خطأ أثناء الرفع<br><br>
                              <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                              </ul>
                            </div>
                            @endif
                    
                              @if(session('success'))
                              <div class="alert alert-success text-right">
                                {{ session('success') }}
                              </div> 
                              @endif
                            <form method="post" class="text-right" action="{{url('openfile')}}" enctype="multipart/form-data">
                                {{csrf_field()}}
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for=""><strong>طلبات وشروط فتح ملف</strong><br></label>
                                            <div class="alert alert-danger" role="alert"><span class="span2 clearfix well"><br> 
                                                1-  خطاب طلب مساعدة <br>
                                                2-  تعريف بالرصيد عن آخر ثلاثة أشهر من البنك <br>
                                                3- تعريف بمعاش التقاعد و التأمينات و الضمان الإجتماعي <br>
                                                4- إفادة من إمام المسجد مصدقة من إدارة الأوقاف ببريدة <br>
                                                5-  صورة لدفتر العائلة بشرط أنه لم يمضي عليه خمس سنوات<br>
                                                6- صورة لبطاقات أحوال الأبناء لمن هم داخل البيت <br>
                                                7-  إحضار تعريف مدرسي لجميع الأولاد(البنين و البنات)<br>
                                                8- صورة لعقد الإيجار بشرط أن يكون لهذا العام <br>
                                                9- شهادة وفاة إن كان العائل متوفى<br>
                                                10- صورة من صك الطلاق أو الهجر <br>
                                                11- صورة للوكالة الشرعية إن كان وكيلاً <br>
                                                12- تعبئة استمارة التعهد بالآداب العامة <br>
                                                13- فاتورة كهرباء المنزل <br>
                                                14-  فاتورة هاتف المنزل <br>
                                                15-  كروكي المنزل <br>
                                                16-  إفادة الجوازات أو مكتب العمل <br>
                                                17-  إفادة البنوك و المصاريف <br>                                                 
                                                <br><br></span>
                                            </div>
                                        </div>

                      <div class="input-group control-group increment" >
                        <input type="file" name="filename[]" class="form-control">
                        <div class="input-group-btn"> 
                          <button class="btn btn-success" type="button" style="background-color:#006837; color:white;"><i class="glyphicon glyphicon-plus"></i>إضافة ملف</button>
                        </div>
                      </div>

                      <div class="clone hide">
                        <div class="control-group input-group" style="margin-top:10px">
                          <input type="file" name="filename[]" class="form-control">
                          <div class="input-group-btn"> 
                            <button class="btn btn-danger" type="button"><i class="glyphicon glyphicon-remove"></i> حذف</button>
                          </div>
                        </div>
                      </div>

          <div class="mt-5"><label for=""><strong>هل تم رفع الملفات</strong><br></label><select name="take_image" class="form-control"><optgroup><option>نعم</option><option>لا</option></optgroup></select><label class="mt-5 p-4 bord">أقر أنا المواطن المدون اسمي اعلاه بأن للزاد الخيري الحق في التأكد و التحقق من صحة هذه المعلومات وتبادلها مع الغير و أفوضهم بأن يحصلوا على ما يلزمهم أو يحتاجون إليه من معلومات تخصني من دوائر حكومية أو أقارب أو جيران أو تخص حساباتي لدى البنوك أو المصارف أو أي جهة اخرى كما أنني أقر بصحة المعلومات وإنني اتحمل تبعات أي قرار يتخذ في حالة وجود أي خلاف لذلك. كما أنني أتعهد بإحضار الوثائق المطلوبة مني خلال عشرة أيام من تاريخ الإستمارة وعند تجاوز التاريخ فللزاد الخيري ببريدة اتخاذ مايراه مناسباً. وقد أخبرت بأن الوثائق المطلوبة مني مايلي: ١- خطاب طلب مساعدة. ٢- تعريف بالرصيد عن آخر ثلاثة أشهر من البنك .٣- تعريف بمعاش التقاعد و التأمينات و الضمان الإجتماعي. ٤-إفادة من إمام المسجد مصدقة من إدارة الأوقاف ببريدة. ٥- صورة لدفتر العائلة بشرط أنه لم يمضي عليه خمس سنوات. ٦- صورة لبطاقات أحوال الأبناء لمن هم داخل البيت. ٧- إحضار تعريف مدرسي لجميع الأولاد(البنين و البنات). ٨- صورة لعقد الإيجار بشرط أن يكون لهذا العام. ٩- شهادة وفاة إن كان العائل متوفى. ١٠- صورة من صك الطلاق أو الهجر. ١١- صورة للوكالة الشرعية إن كان وكيلاً. ١٢- تعبئة استمارة التعهد بالآداب العامة. ١٣- فاتورة كهرباء المنزل. ١٤- فاتورة هاتف المنزل. ١٥- كروكي المنزل. ١٦-إفادة الجوازات أو مكتب العمل. ١٧-إفادة البنوك و المصاريف.&nbsp;<br></label></div>

          <div><input type="radio" class="mr-4"><label class="mr-2">الموافقة على الاقرار</label></div>
          <div class="form-group">
            <button class="btn btns mt-4" type="submit" style="width: 106px; background-color:#006837; color:white;">رفع الملفات</button>
          </div>






<script type="text/javascript">


    $(document).ready(function() {

      $(".btn-success").click(function(){ 
          var html = $(".clone").html();
          $(".increment").after(html);
      });

      $("body").on("click",".btn-danger",function(){ 
          $(this).parents(".control-group").remove();
      });

    });

</script>

@endsection
@section('footer')
    @include('footer')
@endsection