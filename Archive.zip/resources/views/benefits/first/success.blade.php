
@extends('layouts.app')
@section('content')


<div class="alert alert-success text-right" role="alert">
    مستحق،الرجاء اكمال تعبئة البيانات   
</div>


<a href="" type="button" class="btn btn-primary float-right">التالي</a>
@endsection

@section('footer')
    @include('footer')
@endsection
