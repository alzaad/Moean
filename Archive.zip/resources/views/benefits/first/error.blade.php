
@extends('layouts.app')
@section('content')

    <div class="alert alert-danger text-right" role="alert">
    خارج نطاق جمعية الزاد الخيرية  
    </div>
@endsection
@section('footer')
    @include('footer')
@endsection