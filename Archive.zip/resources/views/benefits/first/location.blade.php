@extends('layouts.app')
@section('content')

<form action="{{ route('check_Location') }}"  method="POST">
        @csrf
    <body style="background-image: url({{url('/img/خلفيه%20البرنامج%205%20شفاف.png')}}); font-family:Cairo;">

        <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">الأحياء التابعة لجمعية الزاد الخيرية</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <form>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><select class="form-control"><optgroup label="  "><option value="12"></option><option value="12">الفايزية</option><option value="13">الأفق</option>
                                        <option value="14">الجامعيين</option><option value="14">مبروكة الرواف</option><option value="14">الرابية</option>
                                        <option value="14">الخزامى</option><<option value="14">آخرى</option>/optgroup></select></div>
                                    </div>
                                </div>
                                <div class="form-group"><button class="btn btns mt-4" type="submit">تحقق</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
@endsection
@section('footer')
    @include('footer')
@endsection