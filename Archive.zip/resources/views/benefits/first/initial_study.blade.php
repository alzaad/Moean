@extends('layouts.app')
@section('content')
@section('title', 'الدراسة المبدئية للمتقدم')

<div class="row">
    <div class="col-xs-12 col-sm-12 col-md-12 text-center">
        <ul>
            @foreach ($errors->all() as $error)
                <li class="alert alert-danger text-right">{{ $error }}</li>
            @endforeach
        </ul>
    <div>

        <form action="{{ route('check_initialstudy') }}" class="text-right" method="POST">
                @csrf 
            <body style="background-image: url({{url('/img/خلفيه%20البرنامج%205%20شفاف.png')}}); font-family:Cairo;">

                @if(session()->has('message.level'))
                    <div class="alert alert-{{ session('message.level') }}"> 
                    {!! session('message.content') !!}
                    </div>
                @endif
                <div class="container-fluid conta">
        <div class="row">
            <div class="col">
                <div class="card shadow mb-4" style="text-align: right;">
                    <div class="card-header py-3" style="background: rgb(255,255,255);">
                        <h5 class="m-0 font-weight-bold" style="color: #006837;">الدراسة المبدئية للمتقدم</h5>
                    </div>
                    <div class="card-body">
                        <div class="form-group" style="margin-top: 15px;margin-right: 50px;margin-left: 50px;">
                            <form>
                                <div class="form-row">
                                    <div class="col">
                                        <div class="form-group"><label for=""><strong>عدد التابعين</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>عدد الزوجات</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>عدد الذكور</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>عدد الإناث</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>الراتب</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>الضمان</strong><br></label><input class="form-control" type="text"></div>
                                        <div class="form-group"><label for=""><strong>اخرى</strong><br></label><input class="form-control" type="text"></div>
                                    </div>
                                </div>
                                <div class="form-group"><button class="btn btns mt-4" type="submit">{{__('حفظ')}}</button></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


                    @if(session()->has('success'))
                        <br>
                        <div class="col-4">
                            <button type="submit" class="btn btn-success">{{__('تسجيل بيانات')}}</button>
                        </div>
                    @endif
        </form>
    </div>
</div>
@endsection
@section('footer')
    @include('footer')
@endsection